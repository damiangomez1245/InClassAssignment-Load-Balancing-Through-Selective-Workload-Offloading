from typing import List, Tuple
from greedy import greedy_heuristic

def solve_branch_and_bound(jobs: List[Tuple[str, str, int, int]], capacity_W: int) -> Tuple[int, List[str]]:
    if capacity_W <= 0:
        return 0, []

    sorted_jobs = sorted(
        jobs,
        key=lambda j: (- (j[3] / j[2]), j[2], j[0])
    )
    n = len(sorted_jobs)
    
    # Initialize incumbent with Greedy to prune branches early
    best_value, best_selection = greedy_heuristic(jobs, capacity_W)

    def compute_upper_bound(index, current_cost, current_relief):
        bound = current_relief
        rem_cap = capacity_W - current_cost
        for i in range(index, n):
            j_id, name, cost, relief = sorted_jobs[i]
            if rem_cap >= cost:
                rem_cap -= cost
                bound += relief
            else:
                bound += (rem_cap / cost) * relief
                break
        return bound

    def backtrack(index, current_cost, current_relief, current_ids):
        nonlocal best_value, best_selection

        if current_relief > best_value:
            best_value = current_relief
            best_selection = list(current_ids)

        if index == n:
            return

        ub = compute_upper_bound(index, current_cost, current_relief)
        if ub <= best_value:
            return

        j_id, name, cost, relief = sorted_jobs[index]
        if current_cost + cost <= capacity_W:
            current_ids.append(j_id)
            backtrack(index + 1, current_cost + cost, current_relief + relief, current_ids)
            current_ids.pop()

        if compute_upper_bound(index + 1, current_cost, current_relief) > best_value:
            backtrack(index + 1, current_cost, current_relief, current_ids)

    backtrack(0, 0, 0, [])
    return best_value, best_selection
