from typing import List, Tuple

def greedy_heuristic(
        jobs: List[Tuple[str, str, int, int]],
        capacity_W: int,
) -> Tuple[int, List[str]]:
    if capacity_W <= 0:
        return 0, []

    sorted_jobs = sorted(
        jobs,
        key=lambda job: (
            -(job[3] / job[2]),
            job[2],
            job[0]
        )
    )

    best_load_releif = 0
    chosen_ids = []
    remaining_capacity = capacity_W

    for job in sorted_jobs:
        job_id, name, migration_cost, load_relief = job

        if migration_cost <= remaining_capacity:
            chosen_ids.append(job_id)
            best_load_releif += load_relief
            remaining_capacity -= migration_cost

    return best_load_releif, chosen_ids
